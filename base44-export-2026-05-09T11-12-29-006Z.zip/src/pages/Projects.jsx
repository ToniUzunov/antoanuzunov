const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, ArrowRight, CheckCircle } from 'lucide-react';
import SectionHeader from '../components/shared/SectionHeader';
import GlassCard from '../components/shared/GlassCard';

const BLINDSPOT_IMG = 'https://media.db.com/images/public/69ff0f6cd0375bf5d4d4b8ba/f5de4fe3c_generated_8884898e.png';
const VELOCITY_IMG = 'https://media.db.com/images/public/69ff0f6cd0375bf5d4d4b8ba/6e5a8424d_generated_e4bd646f.png';
const GT20_IMG = 'https://media.db.com/images/public/69ff0f6cd0375bf5d4d4b8ba/6a285886e_generated_f38d99c2.png';

const velocityAchievements = [
'Designed and planned the chassis from scratch',
'Cut, bent, and shaped pipes to create the frame',
'Completed and tested chassis on a track in Bucharest',
'Worked on exterior body planning and prototype panels',
'Prepared the car for Arctic endurance competitions',
'Competed in longest drift, fastest lap, and highest speed',
'Helped land sponsors through structured business proposals'];

export default function Projects() {
  return (
    <div className="pt-24 lg:pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <SectionHeader
          label="Projects"
          title="Building what matters."
          description="Deep dives into the projects that define my journey as an entrepreneur and innovator." />
        

        {/* BlindSpot Innovation */}
        <GlassCard className="mb-12 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <img src="https://media.db.com/images/public/69ff0f6cd0375bf5d4d4b8ba/99d60e712_Untitled_design__2_.png" alt="BlindSpot Innovation" className="w-full h-64 lg:h-full object-cover rounded-3xl" />
            <div className="p-8 lg:p-12">
              <span className="text-xs font-body font-semibold uppercase tracking-widest text-primary">Assistive Technology</span>
              <h3 className="font-heading font-bold text-3xl text-foreground mt-2 mb-4">BlindSpot Innovation</h3>
              <p className="font-body text-muted-foreground leading-relaxed mb-6">
                I founded BlindSpot Innovation to improve the lives of blind and visually impaired individuals through practical assistive technology. My goal is to solve real-world accessibility challenges and help people move through the world with more confidence.
              </p>
              <div className="space-y-4 mb-8">
                {['Problem', 'Vision', 'Product Concept', 'Impact', 'Current Focus'].map((section, i) =>
                <div key={section}>
                    <h4 className="font-heading font-semibold text-sm text-foreground mb-1">{section}</h4>
                    <p className="font-body text-sm text-muted-foreground">
                      {section === 'Problem' && 'Blind and visually impaired individuals face daily mobility and safety challenges that existing solutions don\'t fully address.'}
                      {section === 'Vision' && 'A world where assistive technology enables full independence and confidence for visually impaired people.'}
                      {section === 'Product Concept' && 'An innovative assistive device designed for real-world navigation, safety alerts, and obstacle detection.'}
                      {section === 'Impact' && 'Improving quality of life, safety, and independence for blind and visually impaired communities.'}
                      {section === 'Current Focus' && 'Developing the core technology, refining the product concept, and building partnerships for testing and feedback.'}
                    </p>
                  </div>
                )}
              </div>
              <a
                href="https://blindspot-innovation.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 font-body font-semibold text-sm bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 transition-all shadow-lg shadow-primary/25">
                
                Visit Website <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </GlassCard>

        {/* Velocity-X */}
        <GlassCard className="mb-12 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 lg:p-12 lg:order-1 order-2">
              <span className="text-xs font-body font-semibold uppercase tracking-widest text-cyan-400">Electric Vehicle Engineering</span>
              <h3 className="font-heading font-bold text-3xl text-foreground mt-2 mb-4">Velocity-X Arctic EV Project</h3>
              <p className="font-body text-muted-foreground leading-relaxed mb-6">
                At age 13, I worked with a student team to build a high-performance electric vehicle for the Arctic Challenge. I was involved across the full scope — planning, chassis design, mechanical systems, exterior prototyping, track testing, sponsorship outreach, and preparing for extreme Arctic conditions.
              </p>
              <div className="mb-6">
                <h4 className="font-heading font-semibold text-sm text-foreground mb-3">Key Achievements</h4>
                <div className="space-y-2">
                  {velocityAchievements.map((item, i) =>
                  <div key={i} className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <span className="font-body text-sm text-muted-foreground">{item}</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {['Strategic Planning', 'Team Leadership', 'Design', 'Sponsorship', 'Engineering'].map((tag) =>
                <span key={tag} className="px-3 py-1 text-xs font-body text-cyan-400/80 bg-cyan-400/5 border border-cyan-400/10 rounded-full">
                    {tag}
                  </span>
                )}
              </div>
            </div>
            <img src={VELOCITY_IMG} alt="Velocity-X Arctic EV" className="w-full h-64 lg:h-full object-cover lg:order-2 order-1" />
          </div>
        </GlassCard>

        {/* GT 20 Under 20 */}
        <GlassCard className="overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <img src={GT20_IMG} alt="GT 20 Under 20" className="w-full h-64 lg:h-full object-cover" />
            <div className="p-8 lg:p-12">
              <span className="text-xs font-body font-semibold uppercase tracking-widest text-indigo-400">Youth Entrepreneurship</span>
              <h3 className="font-heading font-bold text-3xl text-foreground mt-2 mb-4">GT 20 Under 20</h3>
              <p className="font-body text-muted-foreground leading-relaxed mb-6">
                GT 20 Under 20 gave me the opportunity to connect with other young builders, refine my ideas, learn from mentors, and grow as an entrepreneur. Being selected among ambitious young innovators has provided invaluable networking and learning experiences.
              </p>
              <div className="flex flex-wrap gap-2 mb-8">
                {['Entrepreneurship', 'Youth Innovation', 'Mentorship', 'Network', 'Growth'].map((tag) =>
                <span key={tag} className="px-3 py-1 text-xs font-body text-indigo-400/80 bg-indigo-400/5 border border-indigo-400/10 rounded-full">
                    {tag}
                  </span>
                )}
              </div>
              <a
                href="https://www.giftedtalented.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 font-body font-semibold text-sm text-primary hover:text-primary/80 transition-colors">
                
                Learn More <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>);

}